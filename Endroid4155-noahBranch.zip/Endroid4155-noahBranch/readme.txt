Endroid

Developed by David Woodman, Milo Boger, Noah Rozelle, and Anna Rubin

The player will traverse and underground dungeon, equipped with a sword and a hand-cannon. 
Using WASD controls, the player can move with a 3rd person point of view as they slay
wave after wave of slimes and brain-puppys.

====================================================================================================================

CONTROLS:

[L-SHIFT]: Activate your powerdash, which can be used as a way of evasion or attacking for
	   a large amount of damage.

  [SPACE]: A utility roll which increases your speed significantly while giving the additional
	   perk of granting invincibility frames during its animation, use this to your advantage.

    [RMB]: Use your special after finding a power-up pack (at the beginning of the game. The two
	   available as of now are the stun-gun, which can bounce off walls and stun, while the
	   other is the flame cannon which deals burning damage to all encompassed by it.

    [LMB]: Swing your sword which is your default way of dealing damage.

=====================================================================================================================

GAME OVERVIEW:

Level 1:
In the first level, the player must kill all slimes and destroy all enemy spawners before they 
can move onto the next room. In level 1, the player has the option to unlock a room, if they find 
the key (located in the top right of the room). Lastly, the player must defeat King Slime, the 
boss for level 1, before moving onto the next level.

Level 2:
In the 2nd level, the player will be fighting Intellect Devourers (brain-puppies). As in the first 
level the player must destroy the enemies and their spawners before moving onto the next room.
In the 2nd level, there are two rooms that can only be accessed by slaying all the spawners (portal's that send
an endless wave of creatures towards you until destroyed). After this, the blue portal will allow you entrance
to the lord of this domain. 

After defeating the last boss, the player may exit the dungeon, and has won the game. 
If the player loses all their lives, then they have lost the game.

Cheat Codes:


